from django.urls import path
from api.views.auth_views import UserRegistrationView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from api.views.profile_views import ProfileView
from api.views.category_views import CategoryListCreateView, CategoryDetailView
from api.views.product_views import ProductListCreateView, ProductDetailView
from api.views.order_views import OrderListCreateView, OrderDetailView  
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView



urlpatterns = [
    # Auth & Profile
    path('register/', UserRegistrationView.as_view(), name='user_register'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('profile/', ProfileView.as_view(), name='profile'),

    # Category CRUD
    path('categories/', CategoryListCreateView.as_view(), name='category_list_create'),
    path('categories/<int:pk>/', CategoryDetailView.as_view(), name='category_detail'),
    
    # Product CRUD
    path('products/', ProductListCreateView.as_view(), name='product_list_create'),
    path('products/<int:pk>/', ProductDetailView.as_view(), name='product_detail'),


    # Order
    path('orders/', OrderListCreateView.as_view(), name='order_list_create'),
    path('orders/<int:pk>/', OrderDetailView.as_view(), name='order_detail'),
]
