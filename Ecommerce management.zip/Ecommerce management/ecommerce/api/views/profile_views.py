from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from api.serializers.profile_serializers import CustomerProfileSerializer

class ProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = CustomerProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user.profile
